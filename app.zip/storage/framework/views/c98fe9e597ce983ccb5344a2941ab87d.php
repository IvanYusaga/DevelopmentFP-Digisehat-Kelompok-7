<?php $__env->startSection('title'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <main id="main" class="main">
    <div class="pagetitle d-flex justify-content-between align-items-center">
        <h1>Berikut Informasi Obat Kamu</h1>
        <a href="<?php echo e(route('obat.form')); ?>">
            <button type="button" class="btn btn-info rounded-pill text-white">Tambah</button>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

        <div class="card">
        <div class="card-body">

            <table class="table table-striped text-center">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Obat</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Cara <br> Penggunaan Obat</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    <td><?php echo e($obat->nama_obat); ?></td>
                    <td><?php echo e($obat->date); ?></td>
                    <td><?php echo e($obat->penggunaan_obat); ?></td>
                    <td><?php echo e($obat->deskripsi); ?></td>
                    <td>
                        <a href="<?php echo e(route('obat.edit', $obat->id_obat)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                        <form action="<?php echo e(route('obat.destroy', $obat->id_obat)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus obat ini?')">
                                <i class="bi bi-trash"></i> Hapus
                            </button>
                        </form>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Tugas MSIB\Final Project Branch\Test6\resources\views/user/manajemenObat/informasiObat.blade.php ENDPATH**/ ?>