<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <main id="main" class="main">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Tugas MSIB\Final Project Branch\Test6\resources\views/user/userBMI.blade.php ENDPATH**/ ?>