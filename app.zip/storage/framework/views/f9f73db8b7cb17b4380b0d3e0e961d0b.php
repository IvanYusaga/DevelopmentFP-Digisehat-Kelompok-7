<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <main id="main" class="main">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="text-center">
        <img src="<?php echo e(asset('style/assets/img/OrangBingung.png')); ?>" alt="Orang Bingung" style="max-width: 300px; margin-bottom: 20px;">
        <br>
        <p>Saat ini kamu belum punya informasi obat kamu.<br>
            Yuk di isi informasi obat kamu!</p>
        <a href="formulirJadwal">
            <button type="button" class="btn btn-info rounded-pill text-white">Atur Sekarang</button>
        </a>
        </div>
</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mainUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Tugas MSIB\Final Project Branch\Test6\resources\views/user/userJadwal.blade.php ENDPATH**/ ?>